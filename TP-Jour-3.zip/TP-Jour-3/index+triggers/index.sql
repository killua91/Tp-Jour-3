-- Index pour la recherche de cours (title et status)
CREATE INDEX idx_courses_title_status ON courses (title, status);

-- Index pour le suivi des étudiants (student_id et status)
CREATE INDEX idx_progress_tracking_student_status ON progress_tracking (student_id, status);

-- Index composé pour les inscriptions (student_id, course_id et enrollment_date)
CREATE INDEX idx_enrollments_student_course_date ON enrollments (student_id, course_id, enrollment_date);

-- Index pour la recherche utilisateur (email et role)
CREATE INDEX idx_users_email_role ON users (email, role);
