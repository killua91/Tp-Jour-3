-- Trigger pour l'historique des prix (avant la mise à jour du prix)
CREATE TRIGGER before_price_update
BEFORE UPDATE ON courses
FOR EACH ROW
BEGIN
    IF OLD.price <> NEW.price THEN
        INSERT INTO price_history (course_id, old_price, new_price, changed_at)
        VALUES (OLD.id, OLD.price, NEW.price, NOW());
    END IF;
END;

-- Trigger pour la mise à jour de la progression (après mise à jour de la progression)
CREATE TRIGGER after_progress_update
AFTER UPDATE ON progress_tracking
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        UPDATE enrollments
        SET progress = (SELECT COUNT(*) FROM progress_tracking WHERE student_id = NEW.student_id AND course_id = NEW.course_id AND status = 'completed')
        WHERE student_id = NEW.student_id AND course_id = NEW.course_id;
    END IF;
END;
