<?php

namespace App\Http\Controllers;

use App\Models\PriceHistory;
use Illuminate\Http\Request;

class PriceHistoryController extends Controller
{
    public function index()
    {
        $priceHistories = PriceHistory::all();
        return response()->json($priceHistories);
    }
}
