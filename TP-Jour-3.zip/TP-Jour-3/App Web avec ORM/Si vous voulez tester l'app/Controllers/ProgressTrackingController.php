<?php

namespace App\Http\Controllers;

use App\Models\ProgressTracking;
use Illuminate\Http\Request;

class ProgressTrackingController extends Controller
{
    public function index()
    {
        $progressTrackings = ProgressTracking::all();
        return response()->json($progressTrackings);
    }
}
