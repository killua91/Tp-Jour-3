<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\EnrollmentController;
use App\Http\Controllers\ProgressTrackingController;
use App\Http\Controllers\PriceHistoryController;
use App\Http\Controllers\LessonController;


Route::get('/', function () {
    return view('welcome');
});

Route::get('/users', [UserController::class, 'index']);
Route::get('/courses', [CourseController::class, 'index']);
Route::get('/enrollments', [EnrollmentController::class, 'index']);
Route::get('/lessons', [LessonController::class, 'index']);
Route::get('/progress-tracking', [ProgressTrackingController::class, 'index']);
Route::get('/price-history', [PriceHistoryController::class, 'index']);

